package com.example.videosaver

import android.app.Application
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            YoutubeDL.getInstance().init(this)
            FFmpeg.getInstance().init(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        // অ্যাপ চালু হলে নিজে থেকে yt-dlp আপডেট
        CoroutineScope(Dispatchers.IO).launch {
            try {
                YoutubeDL.getInstance().updateYoutubeDL(
                    this@App, YoutubeDL.UpdateChannel.NIGHTLY
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
