package com.example.videosaver

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

class MainActivity : ComponentActivity() {
    private val vm: DownloaderViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleShare(intent)
        setContent { MaterialTheme { Screen(vm) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
            // শেয়ার করা টেক্সট থেকে প্রথম লিংক বের করা
            val link = Regex("https?://\\S+").find(text)?.value ?: text
            vm.setUrl(link)
            vm.fetchInfo()
        }
    }
}

@Composable
fun Screen(vm: DownloaderViewModel) {
    val s by vm.state.collectAsState()

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Video Saver", style = MaterialTheme.typography.headlineMedium)

            OutlinedTextField(
                value = s.url,
                onValueChange = vm::setUrl,
                label = { Text("ভিডিও/ফটোর লিংক পেস্ট করুন") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Button(
                onClick = vm::fetchInfo,
                enabled = s.url.isNotBlank() && !s.loading && !s.downloading,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (s.loading) "খোঁজা হচ্ছে..." else "তথ্য দেখুন") }

            s.title?.let { title ->
                s.thumbnail?.let {
                    AsyncImage(
                        model = it, contentDescription = null,
                        modifier = Modifier.fillMaxWidth().height(200.dp)
                    )
                }
                Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 3)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.download(false) }, enabled = !s.downloading,
                        modifier = Modifier.weight(1f)) { Text("ভিডিও (MP4)") }
                    OutlinedButton(onClick = { vm.download(true) }, enabled = !s.downloading,
                        modifier = Modifier.weight(1f)) { Text("অডিও (MP3)") }
                }
            }

            if (s.downloading) {
                LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth())
                TextButton(onClick = vm::cancel) { Text("বাতিল") }
            }
            s.message?.let { Text(it) }

            OutlinedButton(
                onClick = vm::updateEngine,
                enabled = !s.updating && !s.downloading,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (s.updating) "আপডেট হচ্ছে..." else "ইঞ্জিন আপডেট করুন (yt-dlp)") }
        }
    }
}
