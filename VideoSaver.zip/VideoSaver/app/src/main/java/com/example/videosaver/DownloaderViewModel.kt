package com.example.videosaver

import android.app.Application
import android.content.ContentValues
import android.os.Environment
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class UiState(
    val url: String = "",
    val loading: Boolean = false,
    val title: String? = null,
    val thumbnail: String? = null,
    val progress: Float = 0f,
    val downloading: Boolean = false,
    val message: String? = null,
)

class DownloaderViewModel(app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private val processId = "download"

    fun setUrl(url: String) {
        _state.value = UiState(url = url)
    }

    /** ধাপ ১: লিংক থেকে ভিডিওর তথ্য আনা */
    fun fetchInfo() {
        val url = _state.value.url.trim()
        if (url.isEmpty()) return
        _state.value = _state.value.copy(loading = true, message = null, title = null)
        viewModelScope.launch {
            try {
                val info = withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().getInfo(YoutubeDLRequest(url))
                }
                _state.value = _state.value.copy(
                    loading = false, title = info.title, thumbnail = info.thumbnail
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    loading = false, message = "তথ্য আনা যায়নি: ${e.message?.take(150)}"
                )
            }
        }
    }

    /** ধাপ ২: ডাউনলোড (ভিডিও MP4 অথবা শুধু অডিও MP3) */
    fun download(audioOnly: Boolean) {
        val url = _state.value.url.trim()
        _state.value = _state.value.copy(downloading = true, progress = 0f, message = null)
        viewModelScope.launch {
            try {
                val ctx = getApplication<Application>()
                val tmp = File(ctx.cacheDir, "dl").apply { deleteRecursively(); mkdirs() }

                withContext(Dispatchers.IO) {
                    val req = YoutubeDLRequest(url).apply {
                        addOption("-o", "${tmp.absolutePath}/%(title).80s.%(ext)s")
                        addOption("--no-mtime")
                        if (audioOnly) {
                            addOption("-x")
                            addOption("--audio-format", "mp3")
                        } else {
                            addOption("-f", "best[ext=mp4]/best")
                        }
                    }
                    YoutubeDL.getInstance().execute(req, processId) { progress, _, _ ->
                        _state.value = _state.value.copy(progress = progress / 100f)
                    }
                    tmp.listFiles()?.forEach { saveToDownloads(it) }
                    tmp.deleteRecursively()
                }
                _state.value = _state.value.copy(
                    downloading = false, progress = 1f,
                    message = "ডাউনলোড শেষ! Downloads/VideoSaver ফোল্ডারে আছে।"
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    downloading = false, message = "ব্যর্থ: ${e.message?.take(150)}"
                )
            }
        }
    }

    fun cancel() {
        YoutubeDL.getInstance().destroyProcessById(processId)
        _state.value = _state.value.copy(downloading = false, message = "বাতিল করা হয়েছে")
    }

    /** ফাইল ফোনের Downloads/VideoSaver ফোল্ডারে সেভ */
    private fun saveToDownloads(file: File) {
        val resolver = getApplication<Application>().contentResolver
        val mime = when (file.extension.lowercase()) {
            "mp4" -> "video/mp4"; "mp3" -> "audio/mpeg"; "webm" -> "video/webm"
            "jpg", "jpeg" -> "image/jpeg"; "png" -> "image/png"
            else -> "application/octet-stream"
        }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, file.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VideoSaver")
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
        resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
    }
}
